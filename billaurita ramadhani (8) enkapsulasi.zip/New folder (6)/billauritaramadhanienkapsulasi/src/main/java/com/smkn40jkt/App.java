package com.smkn40jkt;

/**
 * Hello world!
 *
 */
public class App 
{
   
        public static void main(String[] args) throws Exception {
            Enkapsulasi encap = new Enkapsulasi();
            encap.setNama("Billaurita Ramadhani");
            encap.setNoAbsen(8);
            encap.setUmur(16);
            System.out.println("Nama        : " + encap.getNama());
            System.out.println("No Absen    : " + encap.getNoAbsen());
            System.out.println("Umur        : " + encap.getUmur());
     
            // Fibonacci fibonacci = new Fibonacci();
            // fibonacci.perhitungan();

            //Genap genap = new Genap();
            //genap.perhitunganGenap();

            Ganjil ganjil = new Ganjil();
            ganjil.perhitunganGanjil();
        }
     
    }
    class Fibonacci{
        int bilanganPertama = 0;
        int bilanganKedua = 1;
        int bilanganKetiga;
        void perhitungan(){
            System.out.print(bilanganPertama + ", ");
            System.out.print(bilanganKedua + ", ");
            for(int i=0; i<10; i++){
                bilanganKetiga = bilanganKedua + bilanganPertama;
                System.out.print(bilanganKetiga + ", ");
                bilanganPertama = bilanganKedua;
                bilanganKedua = bilanganKetiga;
            }
        }
    }
    class Genap{
        int bilanganGenappertama = 0;
        void perhitunganGenap(){
            for(int a = 0 ; a <10 ; a++){
                System.out.println(bilanganGenappertama);
                bilanganGenappertama = bilanganGenappertama + 2;
            }
        }
    }
    class Ganjil{
        int bilanganGanjilpertama = 1;
        void perhitunganGanjil(){
            for(int b = 0 ; b <10 ; b++){
                System.out.println(bilanganGanjilpertama);
                bilanganGanjilpertama = bilanganGanjilpertama + 2;
            }
        }
    }
    class SegitigaPascal{
        public static void main(String args[]) {
            int one[] = {1};
            int n = 13;
            System.out.println("1");
            for (int j = 0; j < n; j++) {
                int two[] = new int[one.length + 1];
                int twoCounter = 0;
                for (int i = 0; i < one.length; i++) {
                    if (i == 0) {
                        two[twoCounter++] = one[i];
                        System.out.print(one[i] + " ");
                    }
                    if (i != 0) {
                        two[twoCounter++] = one[i] + one[i - 1];
                        System.out.print((one[i] + one[i - 1]) + " ");
                    }
                    if (i == one.length - 1) {
                        two[twoCounter++] = one[i];
                        System.out.print(one[i] + " ");
                    }
                }
                System.out.println();
                one = two;
            }
        }
    }
    
    class Enkapsulasi{
        private String nama;
        private int noAbsen;
        private int umur;
        public String getNama() {
            return nama;
        }
        public void setNama(String nama) {
            this.nama = nama;
        }
        public int getNoAbsen() {
            return noAbsen;
        }
        public void setNoAbsen(int noAbsen) {
            this.noAbsen = noAbsen;
        }
        public int getUmur() {
            return umur;
        }
        public void setUmur(int umur) {
            this.umur = umur;
        }    
    }